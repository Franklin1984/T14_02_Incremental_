package voucher_service;
import org.mybatis.spring.annotation.*;
import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
@SpringBootApplication
@MapperScan(basePackages={"repository"})
public class Voucher 
{
	public static void main(String[] args) 
	{
		SpringApplication.run(Voucher.class, args);
		// test
		// test2
	}
}
