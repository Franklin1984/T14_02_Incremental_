package voucher_service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class GlobalExceptionHandleController 
{
	@ExceptionHandler(value=Exception.class)
	public String exceptionHandler(Exception e, Model model) 
	{		
		String message = "error";
		model.addAttribute("message",message);
		return "myError";
	}
}