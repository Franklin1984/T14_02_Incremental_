package voucher_service;
public class NoLoginException extends Exception
{
	public NoLoginException() 
	{
		super();
	}
	public NoLoginException(String message) 
	{
		super(message);
	}
}