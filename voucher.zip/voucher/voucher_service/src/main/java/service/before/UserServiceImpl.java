package service.before;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import get.MD5Util;
import item.Customer;
import repository.before.UserRepository;
@Service
public class UserServiceImpl implements UserService {
	@Autowired 
	private UserRepository userRepository;
	@Override
	public String isUse(Customer bUser) {
		if(userRepository.isUse(bUser).size() > 0) {
			return "no";
		}
		return "ok";
	}
	@Override
	public String register(Customer bUser) {

		bUser.setBpwd(MD5Util.MD5(bUser.getBpwd()));
		if(userRepository.register(bUser) > 0) {
			return "user/login";
		}
		return "user/register";
	}
	@Override
	public String login(Customer bUser, HttpSession session, Model model) {

		bUser.setBpwd(MD5Util.MD5(bUser.getBpwd()));
		String rand = (String)session.getAttribute("rand");
		if(!rand.equalsIgnoreCase(bUser.getCode())) {
			model.addAttribute("errorMessage", "wrong identifying code！");
			return "user/login";
		}
		List<Customer> list = userRepository.login(bUser);
		if(list.size() > 0) {
			session.setAttribute("bUser", list.get(0));
			return "redirect:/";
		}
		model.addAttribute("errorMessage", "wrong email or password！！");
		return "user/login";
	}

}
