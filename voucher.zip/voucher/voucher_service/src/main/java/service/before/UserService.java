package service.before;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import item.Customer;

public interface UserService {
	public String isUse(Customer bUser);
	public String register(Customer bUser);
	public String login(Customer bUser, HttpSession session, Model model);
}
