package service.admin;

import org.springframework.ui.Model;

import item.Voucher_Service_type;

public interface TypeService {
	public String selectAllTypeByPage(Model model, int currentPage);
	public String delete(int id);
	public String addType(Voucher_Service_type goodsType);
}
