package service.admin;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import item.Admin;
import repository.admin.AdminRepository;
@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	private AdminRepository adminRepository;
	@Override
	public String login(Admin aUser, HttpSession session, Model model) {
		List<Admin> list = adminRepository.login(aUser);
		if(list.size() > 0) {
			session.setAttribute("auser", aUser);
			return "forward:/goods/selectAllGoodsByPage?currentPage=1&act=select";
		}else {
			model.addAttribute("errorMessage", "wrong email or password！");
			return "admin/login";
		}
	}
}
