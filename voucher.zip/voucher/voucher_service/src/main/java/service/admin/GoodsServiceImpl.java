package service.admin;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import get.MyUtil;
import item.Voucher_Service;
import repository.admin.GoodsRepository;
@Service
public class GoodsServiceImpl implements GoodsService{
	@Autowired
	private GoodsRepository goodsRepository;

	@Override
	public String selectAllGoodsByPage(Model model, int currentPage, String act) {

	  	int totalCount = goodsRepository.selectAllGoods();

	  	int pageSize = 5;
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Voucher_Service> typeByPage = goodsRepository.selectAllGoodsByPage((currentPage-1)*pageSize, pageSize);
	    model.addAttribute("allGoods", typeByPage);
	    model.addAttribute("totalPage", totalPage);
	    model.addAttribute("currentPage", currentPage);
	    model.addAttribute("act", act);
		return "admin/selectGoods";
	}

	@Override
	public String addGoods(Voucher_Service goods, HttpServletRequest  request, String act) throws IllegalStateException, IOException {
		MultipartFile myfile = goods.getFileName();

		if(!myfile.isEmpty()) {

			String path = "C:\\workspace-spring-tool-suite-4-4.1.1.RELEASE\\eBusiness\\src\\main\\resources\\static\\images";

			String fileName = myfile.getOriginalFilename();

			String fileNewName = MyUtil.getNewFileName(fileName);
			File filePath = new File(path + File.separator + fileNewName);

			if(!filePath.getParentFile().exists()) {
				filePath.getParentFile().mkdirs();
			}

			myfile.transferTo(filePath);

			goods.setGpicture(fileNewName);
		}
		if("add".equals(act)) {
			int n = goodsRepository.addGoods(goods);
			if(n > 0)
				return "redirect:/goods/selectAllGoodsByPage?currentPage=1&act=select";

			return "admin/addGoods";
		}else {
			int n = goodsRepository.updateGoods(goods);
			if(n > 0)
				return "redirect:/goods/selectAllGoodsByPage?currentPage=1&act=updateSelect";

			return "admin/UpdateAGoods";
		}
	}
	@Override
	public String toAddGoods(Voucher_Service goods, Model model) {
		model.addAttribute("goodsType", goodsRepository.selectAllGoodsType());
		return "admin/addGoods";
	}

	@Override
	public String detail(Model model, Integer id, String act) {
		model.addAttribute("goods", goodsRepository.selectAGoods(id));
		if("detail".equals(act))
			return "admin/detail";
		else {
			model.addAttribute("goodsType", goodsRepository.selectAllGoodsType());
			return "admin/updateAGoods";
		}
	}

	@Override
	public String delete(Integer id) {
		if(goodsRepository.selectCartGoods(id).size() > 0 
				|| goodsRepository.selectFocusGoods(id).size() > 0
				|| goodsRepository.selectOrderGoods(id).size() > 0)
			return "no";
		else {
			goodsRepository.deleteAGoods(id);
			return "/goods/selectAllGoodsByPage?currentPage=1&act=deleteSelect";
		}
	}

}
