package service.admin;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;

import item.Voucher_Service;

public interface GoodsService {
	public String selectAllGoodsByPage(Model model, int currentPage, String act);
	public String addGoods(Voucher_Service goods, HttpServletRequest  request, String act) throws IllegalStateException, IOException ;
	public String toAddGoods(Voucher_Service goods, Model model);
	public String detail(Model model, Integer id, String act);
	public String delete(Integer id);
}
