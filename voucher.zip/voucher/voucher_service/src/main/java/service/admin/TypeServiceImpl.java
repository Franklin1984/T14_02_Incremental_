package service.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import item.Voucher_Service;
import item.Voucher_Service_type;
import repository.admin.TypeRepository;
@Service
public class TypeServiceImpl implements TypeService{
	@Autowired
	private TypeRepository typeRepository;
	@Override
	public String selectAllTypeByPage(Model model, int currentPage) {

	  	int totalCount = typeRepository.selectAll();

	  	int pageSize = 2;
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Voucher_Service_type> typeByPage = typeRepository.selectAllTypeByPage((currentPage-1)*pageSize, pageSize);
	    model.addAttribute("allTypes", typeByPage);
	    model.addAttribute("totalPage", totalPage);
	    model.addAttribute("currentPage", currentPage);
		return "admin/selectGoodsType";
	}
	@Override
	public String delete(int id) {
		List<Voucher_Service> list = typeRepository.selectGoods(id);
		if(list.size() > 0) {

			return "no";
		}else {
			typeRepository.deleteType(id);

			return "/type/selectAllTypeByPage?currentPage=1";
		}
	}
	@Override
	public String addType(Voucher_Service_type goodsType) {
		typeRepository.addType(goodsType);
		return "redirect:/type/selectAllTypeByPage?currentPage=1";
	}

}
