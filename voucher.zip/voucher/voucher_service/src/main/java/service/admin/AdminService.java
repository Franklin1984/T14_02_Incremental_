package service.admin;

import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;

import item.Admin;

public interface AdminService {
	public String login(Admin aUser, HttpSession session, Model model);
}
