package service.admin;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import item.Customer;
import repository.admin.UserAndOrderAndOutRepository;
@Service
public class UserAndOrderAndOutServiceImpl implements UserAndOrderAndOutService{
	@Autowired
	private UserAndOrderAndOutRepository userAndOrderAndOutRepository;

	@Override
	public String selectUser(Model model, int currentPage) {

	  	int totalCount = userAndOrderAndOutRepository.selectAllUser();

	  	int pageSize = 5;
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Customer> typeByPage = userAndOrderAndOutRepository.selectUserByPage((currentPage-1)*pageSize, pageSize);
	    model.addAttribute("allUsers", typeByPage);
	    model.addAttribute("totalPage", totalPage);
	    model.addAttribute("currentPage", currentPage);
		return "admin/allUser";
	}

	@Override
	public String deleteUser(Model model, int id) {
		if(userAndOrderAndOutRepository.selectCartUser(id).size() > 0 
				||userAndOrderAndOutRepository.selectOrderUser(id).size() > 0) {
			return "no";
		}else {
			userAndOrderAndOutRepository.deleteUser(id);
			return "/selectUser?currentPage=1";
		}
	}

	@Override
	public String selectOrder(Model model, int currentPage) {

	  	int totalCount = userAndOrderAndOutRepository.selectAllOrder();

	  	int pageSize = 5;
	  	int totalPage = (int)Math.ceil(totalCount*1.0/pageSize);
	  	List<Map<String, Object>> orderByPage = userAndOrderAndOutRepository.selectOrderByPage((currentPage-1)*pageSize, pageSize);
	    model.addAttribute("allOrders", orderByPage);
	    model.addAttribute("totalPage", totalPage);
	    model.addAttribute("currentPage", currentPage);
		return "admin/allOrder";
	}

}
