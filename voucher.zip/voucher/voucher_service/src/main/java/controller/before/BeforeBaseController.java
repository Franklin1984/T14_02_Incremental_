package controller.before;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import voucher_service.NoLoginException;
@Controller
public class BeforeBaseController {

	@ModelAttribute  
    public void isLogin(HttpSession session) throws NoLoginException {
       if(session.getAttribute("customer") == null){  
            throw new NoLoginException("not login in");
       }  
    } 
}