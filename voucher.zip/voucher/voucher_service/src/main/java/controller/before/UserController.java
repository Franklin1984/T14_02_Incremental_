package controller.before;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import item.Customer;
import service.before.UserService;
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	@RequestMapping("/toRegister")
	public String toRegister(@ModelAttribute("bUser") Customer bUser) {
		return "user/register";
	}
	@RequestMapping("/toLogin")
	public String toLogin(@ModelAttribute("bUser") Customer bUser) {
		return "user/login";
	}
	@RequestMapping("/login")
	public String login(@ModelAttribute("bUser") @Validated Customer bUser,
			BindingResult rs, HttpSession session, Model model) {
		if(rs.hasErrors()){
	        return "user/login";
	    }
		return userService.login(bUser, session, model);
	}
	@RequestMapping("/isUse")
	@ResponseBody
	public String isUse(@RequestBody Customer bUser) {
		return userService.isUse(bUser);
	}
	@RequestMapping("/register")
	public String register(@ModelAttribute("bUser") @Validated Customer bUser,BindingResult rs) {
		if(rs.hasErrors()){
	        return "user/register";
	    }
		return userService.register(bUser);
	}
}
