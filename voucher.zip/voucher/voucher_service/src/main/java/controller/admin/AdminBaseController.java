package controller.admin;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import voucher_service.NoLoginException;
@Controller
public class AdminBaseController {

	@ModelAttribute  
    public void isLogin(HttpSession session) throws NoLoginException 
	{      
       if(session.getAttribute("admin") == null)
       {  
            throw new NoLoginException("not login in");
       }  
    } 
}