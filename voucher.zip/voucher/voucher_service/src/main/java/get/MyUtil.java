package get;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.http.HttpSession;

import item.Customer;
public class MyUtil {

	public static String getNewFileName(String oldFileName) {
		int lastIndex = oldFileName.lastIndexOf(".");
		String fileType = oldFileName.substring(lastIndex);
		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMDDHH");
		String time = sdf.format(now);
		String newFileName = time + fileType;
		return newFileName;
	}

	public static Customer getUser(HttpSession session) {
		Customer bUser = (Customer)session.getAttribute("bUser");
		return bUser;
	}
}
