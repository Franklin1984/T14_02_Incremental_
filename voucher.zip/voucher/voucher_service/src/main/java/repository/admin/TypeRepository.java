package repository.admin;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import item.Voucher_Service;
import item.Voucher_Service_type;

@Mapper
public interface TypeRepository {
	int selectAll();
	List<Voucher_Service_type> selectAllTypeByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize);
	int deleteType(int id);
	List<Voucher_Service> selectGoods(int goodstype_id);
	int addType(Voucher_Service_type goodsType);
}
