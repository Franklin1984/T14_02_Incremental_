package repository.admin;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import item.Voucher_Service;
import item.Voucher_Service_type;

@Mapper
public interface GoodsRepository {
	int addGoods(Voucher_Service goods);
	int updateGoods(Voucher_Service goods);
	Voucher_Service selectAGoods(Integer id);
	int selectAllGoods();
	List<Voucher_Service_type> selectAllGoodsType();
	List<Voucher_Service> selectAllGoodsByPage(@Param("startIndex") int startIndex, @Param("perPageSize") int perPageSize);
	int  deleteAGoods(Integer id);
	List<Map<String, Object>> selectFocusGoods(Integer id);
	List<Map<String, Object>> selectCartGoods(Integer id);
	List<Map<String, Object>> selectOrderGoods(Integer id);
}
