package repository.admin;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import item.Admin;

@Mapper
public interface AdminRepository {
	List<Admin> login(Admin aUser);
}
