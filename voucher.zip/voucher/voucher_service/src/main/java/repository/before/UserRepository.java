package repository.before;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import item.Customer;
@Mapper
public interface UserRepository {
	public List<Customer> isUse(Customer bUser);
	public int register(Customer bUser);
	public List<Customer> login(Customer bUser);
}
