package repository.before;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import item.Voucher_Service;
import item.Voucher_Service_type;

@Mapper
public interface IndexRepository {
	public List<Voucher_Service> selectAdvertisementGoods();
	public List<Voucher_Service_type> selectGoodsType();
	public List<Voucher_Service> selectRecommendGoods(Integer tid);
	public List<Voucher_Service> selectLastedGoods(Integer tid);
	public Voucher_Service selectAGoods(Integer id);
	public List<Voucher_Service> search(String mykey);
}
